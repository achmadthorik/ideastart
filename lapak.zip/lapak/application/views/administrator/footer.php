
<strong>Copyright &copy; 2020 - <?php echo date('Y'); ?> <a target='_BLANK' href="https://pesantrenprogrammer.my.id"> lapakmu</a>.</strong> All rights reserved. 