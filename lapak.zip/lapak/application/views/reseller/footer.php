
<strong>Copyright &copy; 2016 - <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com"> Swarakalibata Ci Marketplace - Pelapak Level</a>.</strong> All rights reserved. 